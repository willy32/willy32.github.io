const express = require("express");
const fs = require("fs");
const app = express();
const port = 3000;
let users = JSON.parse(fs.readFileSync(__dirname + "/users.json"));

app.use(express.urlencoded({ extended: false }));
app.use(express.static(__dirname + "/public/"));
app.use(express.json());

app.post('/register', (req, res) => {
    let data = req.body;
    console.log("---> /register");
    CheckExistingUser(data);    //Checks if there is already a user
    res.redirect("/");
});
app.get('/users', (req, res) => {
    res.json(users);
})

app.listen(port);
console.log("Listening on port: " + port);

function CheckExistingUser(data){
    let exists = false;

    users.forEach((user, index) => {
        if(user.txtUsername == data.txtUsername){
            exists = true;
            return;
        }
    });
    if(!exists){
        users.push(data);
        fs.writeFileSync(__dirname + "/users.json", JSON.stringify(users, null, 2));
    }
}