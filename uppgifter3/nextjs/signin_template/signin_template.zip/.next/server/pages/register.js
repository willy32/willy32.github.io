/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/register";
exports.ids = ["pages/register"];
exports.modules = {

/***/ "./styles/Register.module.css":
/*!************************************!*\
  !*** ./styles/Register.module.css ***!
  \************************************/
/***/ ((module) => {

eval("// Exports\nmodule.exports = {\n\t\"main\": \"Register_main__kCavY\"\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zdHlsZXMvUmVnaXN0ZXIubW9kdWxlLmNzcy5qcyIsIm1hcHBpbmdzIjoiQUFBQTtBQUNBO0FBQ0E7QUFDQSIsInNvdXJjZXMiOlsid2VicGFjazovL3NpZ25pbl90ZW1wbGF0ZS8uL3N0eWxlcy9SZWdpc3Rlci5tb2R1bGUuY3NzPzVmYWUiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gRXhwb3J0c1xubW9kdWxlLmV4cG9ydHMgPSB7XG5cdFwibWFpblwiOiBcIlJlZ2lzdGVyX21haW5fX2tDYXZZXCJcbn07XG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./styles/Register.module.css\n");

/***/ }),

/***/ "./styles/RegisterForm.module.css":
/*!****************************************!*\
  !*** ./styles/RegisterForm.module.css ***!
  \****************************************/
/***/ ((module) => {

eval("// Exports\nmodule.exports = {\n\t\"card\": \"RegisterForm_card__b8kHY\"\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zdHlsZXMvUmVnaXN0ZXJGb3JtLm1vZHVsZS5jc3MuanMiLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0EiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9zaWduaW5fdGVtcGxhdGUvLi9zdHlsZXMvUmVnaXN0ZXJGb3JtLm1vZHVsZS5jc3M/ODNiNyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBFeHBvcnRzXG5tb2R1bGUuZXhwb3J0cyA9IHtcblx0XCJjYXJkXCI6IFwiUmVnaXN0ZXJGb3JtX2NhcmRfX2I4a0hZXCJcbn07XG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./styles/RegisterForm.module.css\n");

/***/ }),

/***/ "./components/RegisterForm.tsx":
/*!*************************************!*\
  !*** ./components/RegisterForm.tsx ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _styles_RegisterForm_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../styles/RegisterForm.module.css */ \"./styles/RegisterForm.module.css\");\n/* harmony import */ var _styles_RegisterForm_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_RegisterForm_module_css__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nconst RegisterForm = ()=>{\n    const { 0: name , 1: setName  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(\"\");\n    const { 0: password , 1: setPassword  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(\"\");\n    const { 0: email , 1: setEmail  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(\"\");\n    function submitRegisterForm(e) {\n        e.preventDefault();\n        console.log(\"Password: \" + password);\n    }\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: (_styles_RegisterForm_module_css__WEBPACK_IMPORTED_MODULE_2___default().card),\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h1\", {\n                children: \"Register\"\n            }, void 0, false, {\n                fileName: \"/home/willy/Documents/willy32.github.io/uppgifter3/nextjs/signin_template/components/RegisterForm.tsx\",\n                lineNumber: 15,\n                columnNumber: 9\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"form\", {\n                action: \"#\",\n                method: \"post\",\n                onSubmit: submitRegisterForm,\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                        onChange: ({ target  })=>{\n                            setEmail(target.value);\n                        },\n                        type: \"text\",\n                        name: \"txtName\",\n                        placeholder: \"John Smith\"\n                    }, void 0, false, {\n                        fileName: \"/home/willy/Documents/willy32.github.io/uppgifter3/nextjs/signin_template/components/RegisterForm.tsx\",\n                        lineNumber: 17,\n                        columnNumber: 9\n                    }, undefined),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                        onChange: ({ target  })=>{\n                            setEmail(target.value);\n                        },\n                        type: \"email\",\n                        name: \"txtEmail\",\n                        placeholder: \"yourname@email.com\"\n                    }, void 0, false, {\n                        fileName: \"/home/willy/Documents/willy32.github.io/uppgifter3/nextjs/signin_template/components/RegisterForm.tsx\",\n                        lineNumber: 20,\n                        columnNumber: 11\n                    }, undefined),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                        onChange: ({ target  })=>{\n                            setPassword(target.value);\n                        },\n                        type: \"password\",\n                        name: \"txtPassword\",\n                        placeholder: \"Password\"\n                    }, void 0, false, {\n                        fileName: \"/home/willy/Documents/willy32.github.io/uppgifter3/nextjs/signin_template/components/RegisterForm.tsx\",\n                        lineNumber: 23,\n                        columnNumber: 11\n                    }, undefined),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                        type: \"submit\",\n                        children: \"Register\"\n                    }, void 0, false, {\n                        fileName: \"/home/willy/Documents/willy32.github.io/uppgifter3/nextjs/signin_template/components/RegisterForm.tsx\",\n                        lineNumber: 26,\n                        columnNumber: 11\n                    }, undefined)\n                ]\n            }, void 0, true, {\n                fileName: \"/home/willy/Documents/willy32.github.io/uppgifter3/nextjs/signin_template/components/RegisterForm.tsx\",\n                lineNumber: 16,\n                columnNumber: 9\n            }, undefined)\n        ]\n    }, void 0, true, {\n        fileName: \"/home/willy/Documents/willy32.github.io/uppgifter3/nextjs/signin_template/components/RegisterForm.tsx\",\n        lineNumber: 14,\n        columnNumber: 5\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RegisterForm);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL1JlZ2lzdGVyRm9ybS50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFBO0FBQXNDO0FBQ2dCO0FBRXRELE1BQU1HLFlBQVksR0FBRyxJQUFNO0lBQ3ZCLE1BQU0sS0FBQ0MsSUFBSSxNQUFFQyxPQUFPLE1BQUlKLCtDQUFRLENBQUMsRUFBRSxDQUFDO0lBQ3BDLE1BQU0sS0FBQ0ssUUFBUSxNQUFFQyxXQUFXLE1BQUlOLCtDQUFRLENBQUMsRUFBRSxDQUFDO0lBQzVDLE1BQU0sS0FBQ08sS0FBSyxNQUFFQyxRQUFRLE1BQUlSLCtDQUFRLENBQUMsRUFBRSxDQUFDO0lBRXRDLFNBQVNTLGtCQUFrQixDQUFDQyxDQUFzQixFQUFFO1FBQ2hEQSxDQUFDLENBQUNDLGNBQWMsRUFBRSxDQUFDO1FBQ25CQyxPQUFPLENBQUNDLEdBQUcsQ0FBQyxZQUFZLEdBQUdSLFFBQVEsQ0FBQyxDQUFDO0tBQ3hDO0lBQ0gscUJBQ0UsOERBQUNTLEtBQUc7UUFBQ0MsU0FBUyxFQUFFZCw2RUFBVzs7MEJBQ3ZCLDhEQUFDZ0IsSUFBRTswQkFBQyxVQUFROzs7Ozt5QkFBSzswQkFDakIsOERBQUNDLE1BQUk7Z0JBQUNDLE1BQU0sRUFBQyxHQUFHO2dCQUFDQyxNQUFNLEVBQUMsTUFBTTtnQkFBQ0MsUUFBUSxFQUFFWixrQkFBa0I7O2tDQUMzRCw4REFBQ2EsT0FBSzt3QkFBQ0MsUUFBUSxFQUFFLENBQUMsRUFBQ0MsTUFBTSxHQUFDLEdBQUs7NEJBQzNCaEIsUUFBUSxDQUFDZ0IsTUFBTSxDQUFDQyxLQUFLLENBQUMsQ0FBQzt5QkFDeEI7d0JBQUVDLElBQUksRUFBQyxNQUFNO3dCQUFDdkIsSUFBSSxFQUFDLFNBQVM7d0JBQUN3QixXQUFXLEVBQUMsWUFBWTs7Ozs7aUNBQUU7a0NBQ3hELDhEQUFDTCxPQUFLO3dCQUFDQyxRQUFRLEVBQUUsQ0FBQyxFQUFDQyxNQUFNLEdBQUMsR0FBSzs0QkFDN0JoQixRQUFRLENBQUNnQixNQUFNLENBQUNDLEtBQUssQ0FBQyxDQUFDO3lCQUN4Qjt3QkFBRUMsSUFBSSxFQUFDLE9BQU87d0JBQUN2QixJQUFJLEVBQUMsVUFBVTt3QkFBQ3dCLFdBQVcsRUFBQyxvQkFBb0I7Ozs7O2lDQUFFO2tDQUNsRSw4REFBQ0wsT0FBSzt3QkFBQ0MsUUFBUSxFQUFFLENBQUMsRUFBQ0MsTUFBTSxHQUFDLEdBQUs7NEJBQzdCbEIsV0FBVyxDQUFDa0IsTUFBTSxDQUFDQyxLQUFLLENBQUMsQ0FBQzt5QkFDM0I7d0JBQUVDLElBQUksRUFBQyxVQUFVO3dCQUFDdkIsSUFBSSxFQUFDLGFBQWE7d0JBQUN3QixXQUFXLEVBQUMsVUFBVTs7Ozs7aUNBQUU7a0NBQzlELDhEQUFDQyxRQUFNO3dCQUFDRixJQUFJLEVBQUMsUUFBUTtrQ0FBQyxVQUFROzs7OztpQ0FBUzs7Ozs7O3lCQUNsQzs7Ozs7O2lCQUNILENBQ1I7Q0FDSDtBQUVELGlFQUFleEIsWUFBWSxFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vc2lnbmluX3RlbXBsYXRlLy4vY29tcG9uZW50cy9SZWdpc3RlckZvcm0udHN4PzJhODIiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7dXNlU3RhdGV9IGZyb20gJ3JlYWN0JztcbmltcG9ydCBzdHlsZXMgZnJvbSBcIi4uL3N0eWxlcy9SZWdpc3RlckZvcm0ubW9kdWxlLmNzc1wiXG5cbmNvbnN0IFJlZ2lzdGVyRm9ybSA9ICgpID0+IHtcbiAgICBjb25zdCBbbmFtZSwgc2V0TmFtZV0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgICBjb25zdCBbcGFzc3dvcmQsIHNldFBhc3N3b3JkXSA9IHVzZVN0YXRlKFwiXCIpO1xuICAgIGNvbnN0IFtlbWFpbCwgc2V0RW1haWxdID0gdXNlU3RhdGUoXCJcIik7XG5cbiAgICBmdW5jdGlvbiBzdWJtaXRSZWdpc3RlckZvcm0oZTpSZWFjdC5TeW50aGV0aWNFdmVudCkge1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiUGFzc3dvcmQ6IFwiICsgcGFzc3dvcmQpO1xuICAgIH1cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmNhcmR9PlxuICAgICAgICA8aDE+UmVnaXN0ZXI8L2gxPlxuICAgICAgICA8Zm9ybSBhY3Rpb249XCIjXCIgbWV0aG9kPVwicG9zdFwiIG9uU3VibWl0PXtzdWJtaXRSZWdpc3RlckZvcm19PlxuICAgICAgICA8aW5wdXQgb25DaGFuZ2U9eyh7dGFyZ2V0fSkgPT4ge1xuICAgICAgICAgICAgc2V0RW1haWwodGFyZ2V0LnZhbHVlKTtcbiAgICAgICAgICB9fSB0eXBlPVwidGV4dFwiIG5hbWU9XCJ0eHROYW1lXCIgcGxhY2Vob2xkZXI9XCJKb2huIFNtaXRoXCIvPlxuICAgICAgICAgIDxpbnB1dCBvbkNoYW5nZT17KHt0YXJnZXR9KSA9PiB7XG4gICAgICAgICAgICBzZXRFbWFpbCh0YXJnZXQudmFsdWUpO1xuICAgICAgICAgIH19IHR5cGU9XCJlbWFpbFwiIG5hbWU9XCJ0eHRFbWFpbFwiIHBsYWNlaG9sZGVyPVwieW91cm5hbWVAZW1haWwuY29tXCIvPlxuICAgICAgICAgIDxpbnB1dCBvbkNoYW5nZT17KHt0YXJnZXR9KSA9PiB7XG4gICAgICAgICAgICBzZXRQYXNzd29yZCh0YXJnZXQudmFsdWUpO1xuICAgICAgICAgIH19IHR5cGU9XCJwYXNzd29yZFwiIG5hbWU9XCJ0eHRQYXNzd29yZFwiIHBsYWNlaG9sZGVyPVwiUGFzc3dvcmRcIi8+XG4gICAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCI+UmVnaXN0ZXI8L2J1dHRvbj5cbiAgICAgICAgPC9mb3JtPlxuICAgICAgPC9kaXY+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBSZWdpc3RlckZvcm07Il0sIm5hbWVzIjpbIlJlYWN0IiwidXNlU3RhdGUiLCJzdHlsZXMiLCJSZWdpc3RlckZvcm0iLCJuYW1lIiwic2V0TmFtZSIsInBhc3N3b3JkIiwic2V0UGFzc3dvcmQiLCJlbWFpbCIsInNldEVtYWlsIiwic3VibWl0UmVnaXN0ZXJGb3JtIiwiZSIsInByZXZlbnREZWZhdWx0IiwiY29uc29sZSIsImxvZyIsImRpdiIsImNsYXNzTmFtZSIsImNhcmQiLCJoMSIsImZvcm0iLCJhY3Rpb24iLCJtZXRob2QiLCJvblN1Ym1pdCIsImlucHV0Iiwib25DaGFuZ2UiLCJ0YXJnZXQiLCJ2YWx1ZSIsInR5cGUiLCJwbGFjZWhvbGRlciIsImJ1dHRvbiJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./components/RegisterForm.tsx\n");

/***/ }),

/***/ "./pages/register.tsx":
/*!****************************!*\
  !*** ./pages/register.tsx ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _styles_Register_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../styles/Register.module.css */ \"./styles/Register.module.css\");\n/* harmony import */ var _styles_Register_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_Register_module_css__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var _components_RegisterForm__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/RegisterForm */ \"./components/RegisterForm.tsx\");\n\n\n\n\nconst Register = ()=>{\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: (_styles_Register_module_css__WEBPACK_IMPORTED_MODULE_3___default().main),\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_RegisterForm__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {}, void 0, false, {\n            fileName: \"/home/willy/Documents/willy32.github.io/uppgifter3/nextjs/signin_template/pages/register.tsx\",\n            lineNumber: 8,\n            columnNumber: 7\n        }, undefined)\n    }, void 0, false, {\n        fileName: \"/home/willy/Documents/willy32.github.io/uppgifter3/nextjs/signin_template/pages/register.tsx\",\n        lineNumber: 7,\n        columnNumber: 5\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Register);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9yZWdpc3Rlci50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFBQTtBQUF5QjtBQUMwQjtBQUNHO0FBRXRELE1BQU1HLFFBQVEsR0FBRyxJQUFNO0lBQ3JCLHFCQUNFLDhEQUFDQyxLQUFHO1FBQUNDLFNBQVMsRUFBRUoseUVBQVc7a0JBQ3pCLDRFQUFDQyxnRUFBWTs7OztxQkFBRTs7Ozs7aUJBQ1gsQ0FDUDtDQUNGO0FBRUQsaUVBQWVDLFFBQVEsRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL3NpZ25pbl90ZW1wbGF0ZS8uL3BhZ2VzL3JlZ2lzdGVyLnRzeD9hNmM1Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCdcbmltcG9ydCBzdHlsZXMgZnJvbSBcIi4uL3N0eWxlcy9SZWdpc3Rlci5tb2R1bGUuY3NzXCI7XG5pbXBvcnQgUmVnaXN0ZXJGb3JtIGZyb20gXCIuLi9jb21wb25lbnRzL1JlZ2lzdGVyRm9ybVwiO1xuXG5jb25zdCBSZWdpc3RlciA9ICgpID0+IHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLm1haW59PlxuICAgICAgPFJlZ2lzdGVyRm9ybS8+XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgUmVnaXN0ZXI7Il0sIm5hbWVzIjpbIlJlYWN0Iiwic3R5bGVzIiwiUmVnaXN0ZXJGb3JtIiwiUmVnaXN0ZXIiLCJkaXYiLCJjbGFzc05hbWUiLCJtYWluIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/register.tsx\n");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/register.tsx"));
module.exports = __webpack_exports__;

})();