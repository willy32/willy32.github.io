/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/login";
exports.ids = ["pages/login"];
exports.modules = {

/***/ "./styles/Login.module.css":
/*!*********************************!*\
  !*** ./styles/Login.module.css ***!
  \*********************************/
/***/ ((module) => {

eval("// Exports\nmodule.exports = {\n\t\"main\": \"Login_main__gWxqA\"\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zdHlsZXMvTG9naW4ubW9kdWxlLmNzcy5qcyIsIm1hcHBpbmdzIjoiQUFBQTtBQUNBO0FBQ0E7QUFDQSIsInNvdXJjZXMiOlsid2VicGFjazovL3NpZ25pbl90ZW1wbGF0ZS8uL3N0eWxlcy9Mb2dpbi5tb2R1bGUuY3NzPzUzYTUiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gRXhwb3J0c1xubW9kdWxlLmV4cG9ydHMgPSB7XG5cdFwibWFpblwiOiBcIkxvZ2luX21haW5fX2dXeHFBXCJcbn07XG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./styles/Login.module.css\n");

/***/ }),

/***/ "./styles/LoginForm.module.css":
/*!*************************************!*\
  !*** ./styles/LoginForm.module.css ***!
  \*************************************/
/***/ ((module) => {

eval("// Exports\nmodule.exports = {\n\t\"card\": \"LoginForm_card__d3YRu\"\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zdHlsZXMvTG9naW5Gb3JtLm1vZHVsZS5jc3MuanMiLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0EiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9zaWduaW5fdGVtcGxhdGUvLi9zdHlsZXMvTG9naW5Gb3JtLm1vZHVsZS5jc3M/NzQ0NSJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBFeHBvcnRzXG5tb2R1bGUuZXhwb3J0cyA9IHtcblx0XCJjYXJkXCI6IFwiTG9naW5Gb3JtX2NhcmRfX2QzWVJ1XCJcbn07XG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./styles/LoginForm.module.css\n");

/***/ }),

/***/ "./components/LoginForm.tsx":
/*!**********************************!*\
  !*** ./components/LoginForm.tsx ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _styles_LoginForm_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../styles/LoginForm.module.css */ \"./styles/LoginForm.module.css\");\n/* harmony import */ var _styles_LoginForm_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_LoginForm_module_css__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nconst LoginForm = ()=>{\n    const { 0: password , 1: setPassword  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(\"\");\n    const { 0: email , 1: setEmail  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(\"\");\n    function submitLoginForm(e) {\n        e.preventDefault();\n        console.log(\"Password: \" + password);\n    }\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: (_styles_LoginForm_module_css__WEBPACK_IMPORTED_MODULE_2___default().card),\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h1\", {\n                children: \"Login\"\n            }, void 0, false, {\n                fileName: \"/home/willy/Documents/willy32.github.io/uppgifter3/nextjs/signin_template/components/LoginForm.tsx\",\n                lineNumber: 14,\n                columnNumber: 9\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"form\", {\n                action: \"#\",\n                method: \"post\",\n                onSubmit: submitLoginForm,\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                        onChange: ({ target  })=>{\n                            setEmail(target.value);\n                        },\n                        type: \"email\",\n                        name: \"txtEmail\",\n                        placeholder: \"yourname@email.com\"\n                    }, void 0, false, {\n                        fileName: \"/home/willy/Documents/willy32.github.io/uppgifter3/nextjs/signin_template/components/LoginForm.tsx\",\n                        lineNumber: 16,\n                        columnNumber: 11\n                    }, undefined),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                        onChange: ({ target  })=>{\n                            setPassword(target.value);\n                        },\n                        type: \"password\",\n                        name: \"txtPassword\",\n                        placeholder: \"Password\"\n                    }, void 0, false, {\n                        fileName: \"/home/willy/Documents/willy32.github.io/uppgifter3/nextjs/signin_template/components/LoginForm.tsx\",\n                        lineNumber: 19,\n                        columnNumber: 11\n                    }, undefined),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                        type: \"submit\",\n                        children: \"Login\"\n                    }, void 0, false, {\n                        fileName: \"/home/willy/Documents/willy32.github.io/uppgifter3/nextjs/signin_template/components/LoginForm.tsx\",\n                        lineNumber: 22,\n                        columnNumber: 11\n                    }, undefined)\n                ]\n            }, void 0, true, {\n                fileName: \"/home/willy/Documents/willy32.github.io/uppgifter3/nextjs/signin_template/components/LoginForm.tsx\",\n                lineNumber: 15,\n                columnNumber: 9\n            }, undefined),\n            email\n        ]\n    }, void 0, true, {\n        fileName: \"/home/willy/Documents/willy32.github.io/uppgifter3/nextjs/signin_template/components/LoginForm.tsx\",\n        lineNumber: 13,\n        columnNumber: 5\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LoginForm);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL0xvZ2luRm9ybS50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFBO0FBQXNDO0FBQ2E7QUFFbkQsTUFBTUcsU0FBUyxHQUFHLElBQU07SUFDcEIsTUFBTSxLQUFDQyxRQUFRLE1BQUVDLFdBQVcsTUFBSUosK0NBQVEsQ0FBQyxFQUFFLENBQUM7SUFDNUMsTUFBTSxLQUFDSyxLQUFLLE1BQUVDLFFBQVEsTUFBSU4sK0NBQVEsQ0FBQyxFQUFFLENBQUM7SUFFdEMsU0FBU08sZUFBZSxDQUFDQyxDQUFzQixFQUFFO1FBQzdDQSxDQUFDLENBQUNDLGNBQWMsRUFBRSxDQUFDO1FBQ25CQyxPQUFPLENBQUNDLEdBQUcsQ0FBQyxZQUFZLEdBQUdSLFFBQVEsQ0FBQyxDQUFDO0tBQ3hDO0lBQ0gscUJBQ0UsOERBQUNTLEtBQUc7UUFBQ0MsU0FBUyxFQUFFWiwwRUFBVzs7MEJBQ3ZCLDhEQUFDYyxJQUFFOzBCQUFDLE9BQUs7Ozs7O3lCQUFLOzBCQUNkLDhEQUFDQyxNQUFJO2dCQUFDQyxNQUFNLEVBQUMsR0FBRztnQkFBQ0MsTUFBTSxFQUFDLE1BQU07Z0JBQUNDLFFBQVEsRUFBRVosZUFBZTs7a0NBQ3RELDhEQUFDYSxPQUFLO3dCQUFDQyxRQUFRLEVBQUUsQ0FBQyxFQUFDQyxNQUFNLEdBQUMsR0FBSzs0QkFDN0JoQixRQUFRLENBQUNnQixNQUFNLENBQUNDLEtBQUssQ0FBQyxDQUFDO3lCQUN4Qjt3QkFBRUMsSUFBSSxFQUFDLE9BQU87d0JBQUNDLElBQUksRUFBQyxVQUFVO3dCQUFDQyxXQUFXLEVBQUMsb0JBQW9COzs7OztpQ0FBRTtrQ0FDbEUsOERBQUNOLE9BQUs7d0JBQUNDLFFBQVEsRUFBRSxDQUFDLEVBQUNDLE1BQU0sR0FBQyxHQUFLOzRCQUM3QmxCLFdBQVcsQ0FBQ2tCLE1BQU0sQ0FBQ0MsS0FBSyxDQUFDLENBQUM7eUJBQzNCO3dCQUFFQyxJQUFJLEVBQUMsVUFBVTt3QkFBQ0MsSUFBSSxFQUFDLGFBQWE7d0JBQUNDLFdBQVcsRUFBQyxVQUFVOzs7OztpQ0FBRTtrQ0FDOUQsOERBQUNDLFFBQU07d0JBQUNILElBQUksRUFBQyxRQUFRO2tDQUFDLE9BQUs7Ozs7O2lDQUFTOzs7Ozs7eUJBQy9CO1lBQ05uQixLQUFLOzs7Ozs7aUJBQ0YsQ0FDUjtDQUNIO0FBRUQsaUVBQWVILFNBQVMsRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL3NpZ25pbl90ZW1wbGF0ZS8uL2NvbXBvbmVudHMvTG9naW5Gb3JtLnRzeD81YjA5Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwge3VzZVN0YXRlfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgc3R5bGVzIGZyb20gXCIuLi9zdHlsZXMvTG9naW5Gb3JtLm1vZHVsZS5jc3NcIlxuXG5jb25zdCBMb2dpbkZvcm0gPSAoKSA9PiB7XG4gICAgY29uc3QgW3Bhc3N3b3JkLCBzZXRQYXNzd29yZF0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgICBjb25zdCBbZW1haWwsIHNldEVtYWlsXSA9IHVzZVN0YXRlKFwiXCIpO1xuXG4gICAgZnVuY3Rpb24gc3VibWl0TG9naW5Gb3JtKGU6UmVhY3QuU3ludGhldGljRXZlbnQpIHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICBjb25zb2xlLmxvZyhcIlBhc3N3b3JkOiBcIiArIHBhc3N3b3JkKTtcbiAgICB9XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5jYXJkfT5cbiAgICAgICAgPGgxPkxvZ2luPC9oMT5cbiAgICAgICAgPGZvcm0gYWN0aW9uPVwiI1wiIG1ldGhvZD1cInBvc3RcIiBvblN1Ym1pdD17c3VibWl0TG9naW5Gb3JtfT5cbiAgICAgICAgICA8aW5wdXQgb25DaGFuZ2U9eyh7dGFyZ2V0fSkgPT4ge1xuICAgICAgICAgICAgc2V0RW1haWwodGFyZ2V0LnZhbHVlKTtcbiAgICAgICAgICB9fSB0eXBlPVwiZW1haWxcIiBuYW1lPVwidHh0RW1haWxcIiBwbGFjZWhvbGRlcj1cInlvdXJuYW1lQGVtYWlsLmNvbVwiLz5cbiAgICAgICAgICA8aW5wdXQgb25DaGFuZ2U9eyh7dGFyZ2V0fSkgPT4ge1xuICAgICAgICAgICAgc2V0UGFzc3dvcmQodGFyZ2V0LnZhbHVlKTtcbiAgICAgICAgICB9fSB0eXBlPVwicGFzc3dvcmRcIiBuYW1lPVwidHh0UGFzc3dvcmRcIiBwbGFjZWhvbGRlcj1cIlBhc3N3b3JkXCIvPlxuICAgICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiPkxvZ2luPC9idXR0b24+XG4gICAgICAgIDwvZm9ybT5cbiAgICAgICAge2VtYWlsfVxuICAgICAgPC9kaXY+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBMb2dpbkZvcm07Il0sIm5hbWVzIjpbIlJlYWN0IiwidXNlU3RhdGUiLCJzdHlsZXMiLCJMb2dpbkZvcm0iLCJwYXNzd29yZCIsInNldFBhc3N3b3JkIiwiZW1haWwiLCJzZXRFbWFpbCIsInN1Ym1pdExvZ2luRm9ybSIsImUiLCJwcmV2ZW50RGVmYXVsdCIsImNvbnNvbGUiLCJsb2ciLCJkaXYiLCJjbGFzc05hbWUiLCJjYXJkIiwiaDEiLCJmb3JtIiwiYWN0aW9uIiwibWV0aG9kIiwib25TdWJtaXQiLCJpbnB1dCIsIm9uQ2hhbmdlIiwidGFyZ2V0IiwidmFsdWUiLCJ0eXBlIiwibmFtZSIsInBsYWNlaG9sZGVyIiwiYnV0dG9uIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./components/LoginForm.tsx\n");

/***/ }),

/***/ "./pages/login.tsx":
/*!*************************!*\
  !*** ./pages/login.tsx ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _styles_Login_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../styles/Login.module.css */ \"./styles/Login.module.css\");\n/* harmony import */ var _styles_Login_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_Login_module_css__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var _components_LoginForm__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/LoginForm */ \"./components/LoginForm.tsx\");\n\n\n\n\nconst Login = ()=>{\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: (_styles_Login_module_css__WEBPACK_IMPORTED_MODULE_3___default().main),\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_LoginForm__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {}, void 0, false, {\n            fileName: \"/home/willy/Documents/willy32.github.io/uppgifter3/nextjs/signin_template/pages/login.tsx\",\n            lineNumber: 8,\n            columnNumber: 7\n        }, undefined)\n    }, void 0, false, {\n        fileName: \"/home/willy/Documents/willy32.github.io/uppgifter3/nextjs/signin_template/pages/login.tsx\",\n        lineNumber: 7,\n        columnNumber: 5\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Login);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9sb2dpbi50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFBQTtBQUF5QjtBQUN1QjtBQUNBO0FBRWhELE1BQU1HLEtBQUssR0FBRyxJQUFNO0lBQ2xCLHFCQUNFLDhEQUFDQyxLQUFHO1FBQUNDLFNBQVMsRUFBRUosc0VBQVc7a0JBQ3pCLDRFQUFDQyw2REFBUzs7OztxQkFBRTs7Ozs7aUJBQ1IsQ0FDUDtDQUNGO0FBRUQsaUVBQWVDLEtBQUssRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL3NpZ25pbl90ZW1wbGF0ZS8uL3BhZ2VzL2xvZ2luLnRzeD83MjQzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCdcbmltcG9ydCBzdHlsZXMgZnJvbSBcIi4uL3N0eWxlcy9Mb2dpbi5tb2R1bGUuY3NzXCI7XG5pbXBvcnQgTG9naW5Gb3JtIGZyb20gXCIuLi9jb21wb25lbnRzL0xvZ2luRm9ybVwiO1xuXG5jb25zdCBMb2dpbiA9ICgpID0+IHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLm1haW59PlxuICAgICAgPExvZ2luRm9ybS8+XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgTG9naW47Il0sIm5hbWVzIjpbIlJlYWN0Iiwic3R5bGVzIiwiTG9naW5Gb3JtIiwiTG9naW4iLCJkaXYiLCJjbGFzc05hbWUiLCJtYWluIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/login.tsx\n");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/login.tsx"));
module.exports = __webpack_exports__;

})();