import React, {useState} from 'react';
import styles from "../styles/RegisterForm.module.css"

const RegisterForm = () => {
    const [name, setName] = useState("");
    const [password, setPassword] = useState("");
    const [email, setEmail] = useState("");

    function submitRegisterForm(e:React.SyntheticEvent) {
        e.preventDefault();
        console.log("Password: " + password);
    }
  return (
    <div className={styles.card}>
        <h1>Register</h1>
        <form action="#" method="post" onSubmit={submitRegisterForm}>
        <input onChange={({target}) => {
            setEmail(target.value);
          }} type="text" name="txtName" placeholder="John Smith"/>
          <input onChange={({target}) => {
            setEmail(target.value);
          }} type="email" name="txtEmail" placeholder="yourname@email.com"/>
          <input onChange={({target}) => {
            setPassword(target.value);
          }} type="password" name="txtPassword" placeholder="Password"/>
          <button type="submit">Register</button>
        </form>
      </div>
  );
};

export default RegisterForm;