import React from 'react';
import styles from "../styles/Layout.module.css"

const Footer = () => {
  return (
    <div className={styles.footer}>
        Copyright Vercel 2022©
    </div>
  );
};

export default Footer;