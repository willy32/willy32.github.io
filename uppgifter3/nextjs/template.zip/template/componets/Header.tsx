import React from 'react'
import styles from '../styles/Layout.module.css'

const Header = () => {
  return (
    <div className={styles.header}>
        <div className={styles.logo}>logo</div>
        <div>
            <h1>SignUp</h1>
            <h1>Login</h1>
        </div>
    </div>
  )
}

export default Header